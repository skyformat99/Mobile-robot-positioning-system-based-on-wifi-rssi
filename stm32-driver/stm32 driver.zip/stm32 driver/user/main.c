#include "public.h"
#include "pwm.h"
#include "DriveIO.h"
#include <string.h>
#include <stdio.h>
#include "stm32f10x.h"
#include "JY901.h"
#include "UART1.h"
#include "UART2.h"
#include "UART3.h"
#include "DIO.h"
#include "systick.h"
#include "PID.h"
#include "printf.h"
char UARTReveived = 0;
char uart_data[16];
int main()
{
	char cmd;
	short int speed;
	short int angle;
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);	//����NVIC�жϷ���2:2λ��ռ���ȼ���2λ��Ӧ���ȼ�
	TIM3_PWM_Init(3599,0,3599);
	TIM4_PWM_Init(3599,0,3599);
	Initial_UART3(9600);
	
	while(1)
	{
		if(UARTReveived == 1)
		{
			UARTReveived = 0;
			getData(uart_data,&cmd,&speed,&angle);
			motor_col(&cmd, speed, "noaver", angle);
		}
	}
}

