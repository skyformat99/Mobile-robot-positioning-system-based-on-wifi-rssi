#ifndef _PID_H
#define _PID_H
#include "stm32f10x.h"


void IncPIDInit(void);
float IncPIDCalc(float NextPoint);
typedef struct 
{
   __IO int      SetPoint;                                 //�趨Ŀ�� Desired Value
   __IO double   Proportion;                               //�������� Proportional Const
   __IO double   Integral;                                 //���ֳ��� Integral Const
   __IO double   Derivative;                               //΢�ֳ��� Derivative Const
   __IO int      LastError;                                //Error[-1]
   __IO int      PrevError;                                //Error[-2]
}PID;






#define  P_DATA      1.5                                //P����
#define  I_DATA      0                                //I����
#define  D_DATA      0                              //D����







#endif
