#ifndef __UART3_H
#define __UART3_H
#include "stm32f10x.h"

void Initial_UART3(unsigned long baudrate);
void USART3_IRQHandler(void);
void getData(char rxData[16], char *cmd, short int *speed, short int *angle);

#endif
