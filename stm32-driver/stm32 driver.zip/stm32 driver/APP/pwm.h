#ifndef _pwm_H
#define _pwm_H
#include "stm32f10x.h"

void TIM3_PWM_Init(u16 arr,u16 psc,u16 duty);
void TIM4_PWM_Init(u16 arr,u16 psc,u16 duty);

void TIM3_CH1_Duty(u16 duty);
void TIM3_CH2_Duty(u16 duty);
void TIM3_CH3_Duty(u16 duty);
void TIM3_CH4_Duty(u16 duty);

void TIM4_CH1_Duty(u16 duty);
void TIM4_CH2_Duty(u16 duty);
void TIM4_CH3_Duty(u16 duty);
void TIM4_CH4_Duty(u16 duty);

void forward(void);
void backward(void);
void left(void);
void right(void);

int motor_col(char *cmd, int Duty, char * ecmd, int error_duty);

#endif
